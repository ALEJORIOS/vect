from setuptools import setup
from setuptools import find_packages
setup(

    name = "vect",
    version = "0.2",
    description = "This powerful tool can help you in vector related work in python",
    author = "Alejandro Ríos",
    keywords = ["vect", "vector", "algebra"],
    packages = ["vect","vect"],
)