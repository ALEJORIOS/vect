import vector
v = vector.array([[1,-1,1],[2,2,3],[-2,-3,-1]])
v2 = vector.array([[1,0,4],[0,2,5],[1,3,0]])

print(v@v2)
