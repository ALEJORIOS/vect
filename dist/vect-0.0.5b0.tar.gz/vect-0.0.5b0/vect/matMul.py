def matMultiplication(matrix_one, matrix_two):
    dimensions_one = (len(matrix_one), len(matrix_one[0]))
    dimensions_two = (len(matrix_two), len(matrix_two[0]))
    return dimensions_one, dimensions_two